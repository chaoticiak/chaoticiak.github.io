# don't scroll down to avoid spoilers



































































































import math

class MyValueError(ValueError):
    pass

def hyper(m,n,p):
    if p == 1:
        return m+n
    if p == 2:
        return m*n
    if p == 3:
        log_result = math.log(m, 10) * n
        if log_result > 1000:
            raise MyValueError("Result is too large. You shouldn't need anything remotely this large.")
        return m**n
    if n == 1:
        return m
    r = 1
    for i in range(n):
        r = hyper(m, r, p-1)
    return r

def clean(s):
    return "".join(filter(lambda x: x in "()", s))

def depths(s):
    s = clean(s)
    res = [0]
    for i in s:
        if i == "(":
            res.append(res[-1]+1)
        if i == ")":
            res.append(res[-1]-1)
    return res

def verify(s):
    if s == "":
        raise MyValueError("Empty string.")
    d = depths(s)
    open_paren = []
    for i in range(1, len(d)):
        if d[i] < 0:
            raise MyValueError("Unmatched closing bracket at position {}.", i)
        if d[i]-d[i-1] == 1:
            open_paren.append(i)
        else:
            open_paren.pop()
    if open_paren:
        raise MyValueError("Unmatched opening bracket at position {}.", open_paren[-1])

def _evaluate(s):
    if s == "()" * (len(s) // 2): return len(s) // 2

    d = depths(s)
    for i in range(-2, -len(s), -1):
        if d[i] == 0: break
    else:
        raise MyValueError("Missing first operand before {}.", s)
    i += 1

    first = s[:i]
    second = s[i:]
    leftlevel = 0
    while s[i+leftlevel] == "(": leftlevel += 1
    rightlevel = 0
    while s[-1-rightlevel] == ")": rightlevel += 1
    level = min(d[i-1+leftlevel:-rightlevel])
    if level*2 == -i: level -= 1

    resfirst = _evaluate(first)
    if second == "()":
        raise MyValueError("Missing second operand after {}.", first)
    ressecond = _evaluate(second[level:-level])
    return hyper(resfirst, ressecond, level)

def evaluate(s):
    verify(s)
    return _evaluate(s)

def extract(x):
    x = x//2 - 9
    if 1 <= x <= 26: return chr(64+x)
    return "-"

def interactive():
    targets = [36, 373, 1199, 4927, 65536, 7625597550523]
    first_target_met = False

    def target_msg():
        if not first_target_met:
            print("Target: {}".format(targets[0]))
        else:
            print("Targets: {}".format(", ".join(map(str, targets))))
    
    def help_msg():
        print("Programs contain only ( and ).")
        print("All programs theoretically terminate, but due to practical reasons, this implementation might error out instead.")
        print("To quit, enter Q. To show this help message again, enter H.")
        target_msg()

    def eval_msg(prog):
        nonlocal first_target_met

        res = evaluate(prog)
        print("{}: {}".format(prog, res))
        if first_target_met:
            print("Extracted letter: {}".format(extract(len(prog))))
        if not first_target_met and res == targets[0]:
            print("You hit the target! Now you have more targets.")
            first_target_met = True
            target_msg()
        elif first_target_met and res in targets:
            print("You hit the target! But is that the shortest? Only take the extracted letter if it's the shortest.")

    help_msg()
    while True:
        prog = input(">>> ").upper().strip()
        if prog == "Q": return
        if prog == "H":
            help_msg()
            continue
        
        prog = clean(prog)
        try:
            eval_msg(prog)
        except MyValueError as e:
            print("Error:", e.args[0].format(*e.args[1:]))
        except Exception as e:
            print("Unexpected error:", repr(e))
            print("Tell the author of this error.")

if __name__ == "__main__":
    interactive()
